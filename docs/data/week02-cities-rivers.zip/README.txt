Cities Near Rivers: practice data for CE 414 Week 2 (ModelBuilder Part A)

Three shapefiles, all in WGS 1984 geographic coordinates (EPSG:4326), clipped to the
conterminous United States (longitude -125 to -66, latitude 24 to 50):

  us_cities.shp    678 populated places (Natural Earth 1:10m populated places, ADM0 = United States)
  us_rivers.shp    158 river and lake centerline segments (Natural Earth 1:10m rivers + lake centerlines)
  us_boundary.shp  the country outline used for the clip (Natural Earth 1:10m admin 0 countries)

Source: Natural Earth, https://www.naturalearthdata.com/ (public domain; no attribution required,
but "Made with Natural Earth" is appreciated). Prepared 2026-09-07 for BYU CE 414 with arcpy; nothing
was edited by hand.

The exercise: project both layers to USA Contiguous Equidistant Conic, buffer the rivers 10 miles,
intersect with the cities, and count. Expected answer: 256 of 678 cities (38 %).
